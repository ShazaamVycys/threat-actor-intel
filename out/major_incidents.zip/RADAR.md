# Incident radar — 2026-11-24T00:41Z

1 new vendor IOC report(s), 2 new CISA KEV entries since the last radar run.

## New vendor IOC reports

| Vendor | Report | Date | IOCs | Actors named | Watched incident |
|---|---|---|---|---|---|
| Unit 42 | [Widespread Vishing via Legal-Themed Domains](https://github.com/PaloAltoNetworks/Unit42-timely-threat-intel/blob/main/2026-11-23-Legal-themed-vishing-activity.txt) | 2026-11-23 | 0 |  |  |

## New CISA KEV entries

| CVE | Product | Added | Ransomware | Watched incident |
|---|---|---|---|---|
| CVE-2026-133968 | Project MONAI MONAI Label | 2026-11-23 | Unknown |  |
| CVE-2026-134624 | N-able MailAssure | 2026-11-23 | Unknown |  |

## Watched incidents

- `ai-inference-providers-prompt-theft-2026` Months-long prompt theft at AI inference providers (OpenRouter removes three providers)
- `artex-2026` ARTEX agentic AI penetration-testing framework abused in intrusions
- `austria-foreign-ministry-2026` Austrian Foreign Ministry website breach exposing staff contact details
- `beget-2026` Destructive wiper attack on Russian hosting provider Beget's cloud platform
- `bell-canada-2026` Bell Canada "agentic threat actor" intrusion stealing customer data
- `binance-theft-2026` Binance $6.3 billion cryptocurrency theft
- `cleverbridge-2026` Cleverbridge payment platform breach exposing card numbers and CVVs of software vendors' customers
- `equinor-2026` Equinor IT systems cyberattack
- `european-commission-2026` European Commission AI-assisted cyberattack disrupting internal services
- `fbi-ncic-2026` FBI National Crime Information Center (NCIC) breach
- `france-supermarket-refrigeration-2026` Destructive attacks on French supermarket refrigeration controllers
- `microsoft-agent-framework-pypi-2026` Microsoft Agent Framework PyPI package compromised with a cloud-credential stealer
- `microsoft-entra-connect-health-2026` Microsoft Entra Connect Health flaw abused to access tenant contact and configuration metadata
- `optimizely-2026` Optimizely supply-chain attack injecting malicious JavaScript into 178 organizations' websites
- `qubole-aws-2026` Qubole cross-account AWS access abused to breach customer cloud environments
- `usda-2026` US Department of Agriculture security incident forcing multi-day system outages
