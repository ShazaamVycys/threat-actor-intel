# Incident radar — 2026-11-21T00:41Z

0 new vendor IOC report(s), 4 new CISA KEV entries since the last radar run.

## New CISA KEV entries

| CVE | Product | Added | Ransomware | Watched incident |
|---|---|---|---|---|
| CVE-2026-129448 | Apache Roller | 2026-11-20 | Unknown |  |
| CVE-2026-123890 | Broadcom VMware vCenter | 2026-11-20 | Unknown |  |
| CVE-2025-42884 | SAP NetWeaver | 2026-11-20 | Unknown |  |
| CVE-2026-76466 | Cisco Expressway Series | 2026-11-20 | Unknown |  |

## Watched incidents

- `artex-2026` ARTEX agentic AI penetration-testing framework abused in intrusions
- `binance-theft-2026` Binance $6.3 billion cryptocurrency theft
- `equinor-2026` Equinor IT systems cyberattack
- `european-commission-2026` European Commission AI-assisted cyberattack disrupting internal services
- `qubole-aws-2026` Qubole cross-account AWS access abused to breach customer cloud environments
