# Incident radar — 2026-11-20T14:30Z

2 new vendor IOC report(s), 0 new CISA KEV entries since the last radar run.

## New vendor IOC reports

| Vendor | Report | Date | IOCs | Actors named | Watched incident |
|---|---|---|---|---|---|
| Cisco Talos | [ARTEX and beyond: AI-enabled penetration testing platforms](https://github.com/Cisco-Talos/IOCs/blob/main/2026/11/artex-and-beyond.json) | 2026-11-13 | ipv4 2546 |  | artex-2026 |
| Cisco Talos | [UAT-12643: Suspected North Korea-aligned actor blends blockchain resilience with targeted ](https://github.com/Cisco-Talos/IOCs/blob/main/2026/11/uat-12643-suspected-north-korea-aligned-actor-blends-blockchain-resilience-with-targeted-infostealing.json) | 2026-11-18 | hash 11, ipv4 1 |  |  |

## Watched incidents

- `artex-2026` ARTEX agentic AI penetration-testing framework abused in intrusions
- `binance-theft-2026` Binance $6.3 billion cryptocurrency theft
