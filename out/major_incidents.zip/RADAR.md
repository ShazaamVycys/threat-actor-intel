# Incident radar — 2026-11-20T18:41Z

1 new vendor IOC report(s), 0 new CISA KEV entries since the last radar run.

## New vendor IOC reports

| Vendor | Report | Date | IOCs | Actors named | Watched incident |
|---|---|---|---|---|---|
| Unit 42 | [Fake PDF-Reader Download Uses Browser-in-the-Browser Window to Deliver Packages Abusing RM](https://github.com/PaloAltoNetworks/Unit42-timely-threat-intel/blob/main/2026-11-20-RRM-packages-disguised-as-PDF-reader-software.txt) | 2026-11-20 | url 74, domain 56, hash 4 |  |  |

## Watched incidents

- `artex-2026` ARTEX agentic AI penetration-testing framework abused in intrusions
- `binance-theft-2026` Binance $6.3 billion cryptocurrency theft
